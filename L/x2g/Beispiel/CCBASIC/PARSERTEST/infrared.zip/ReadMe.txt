Hallo.
Die .doc-Datei ist die Projektdokumentation im Word97-Format.
Die .bas-Datei enth�lt eine einfache Demonstration des IR-Treibers.
Um was von dieser Demonstration zu sehen, braucht man auf der anderen
Seite des Nullmodems ein Terminal, dass die empfangenen Bytes als
Zahlen darzustellen vermag (Denn das Byte FF-Hex ist nun mal kein
druckbares Zeichen). Jedes IR-Wort wird mit 2 Bytes �bertragen.
Die .sys-Datei enth�lt den Maschinencode des IR-Treibers: Mit z.B. Notepad
�ffnen, alles markieren, und ganz am Ende des Basic-Programms anh�ngen.
Das gilt auch f�r das Basic-Demo "InfraRed.bas".

Keine Haftung auf irgendetwas!

Mario.Fischer@eikon.tum.de