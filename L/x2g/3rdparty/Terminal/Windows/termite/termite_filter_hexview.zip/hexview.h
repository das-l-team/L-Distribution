#ifndef HEXVIEW_H
#define HEXVIEW_H

#define INFOTEXT          100

#define IDD_HEXENTRY      101
#define IDD_HEXDISPLAY    102
#define IDD_BYTESPERLINE  103
#define IDD_HEXPREFIX     104
#define IDD_HEXLBF        105

#endif /* HEXVIEW_H */
