#ifndef HIGHLIGHT_H
#define HIGHLIGHT_H

#define INFOTEXT      100

#define IDD_MATCH1    200
#define IDD_MATCH2    201
#define IDD_MATCH3    202
#define IDD_MATCH4    203
#define IDD_MATCH5    204

#define IDD_COLOUR1   250
#define IDD_COLOUR2   251
#define IDD_COLOUR3   252
#define IDD_COLOUR4   253
#define IDD_COLOUR5   254
#define IDD_COLOUR6   255
#define IDD_COLOUR7   256
#define IDD_COLOUR8   257
#define IDD_COLOUR9   258
#define IDD_COLOUR10  259
#define IDD_COLOUR11  260
#define IDD_COLOUR12  261
#define IDD_COLOUR13  262
#define IDD_COLOUR14  263
#define IDD_COLOUR15  264

#endif /* HIGHLIGHT_H */
