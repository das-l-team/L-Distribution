The Highlight filter uses the SLRE library for matching regular expressions.
The source code for the SLRE library is not included in this ZIP file. It can
be downloaded from http://cesanta.com/slre.shtml.
