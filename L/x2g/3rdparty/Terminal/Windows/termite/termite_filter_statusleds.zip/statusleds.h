#ifndef STATUSLEDS_H
#define STATUSLEDS_H

#define INFOTEXT          100

#endif /* STATUSLEDS_H */
