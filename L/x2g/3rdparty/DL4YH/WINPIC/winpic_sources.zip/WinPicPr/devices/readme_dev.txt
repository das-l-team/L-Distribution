README for WinPic's subdirectory \devices
----------------------------------------------------------

This subdirectory MAY contain some files which allow
WinPic to show some "important" CONFIGURATION BITS
on the Device/Config tabsheet. 

If you have installed Microchip's MPLAB, you can copy a few
device-definition files from MPLAB IDE\Device\*.dev
into this location. 
Alternatively, you can define the full path into MPBLAB's 
device directory on WinPic's "Options" tab.

 ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! !
 ! ! Please read Microchip's LICENSE GRANT   ! ! 
 ! ! before doing that (see next chapter)    ! !
 ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! !

WinPic will then be able to "decode" some important bit groups
in the CONFIGURATION REGISTERS, and let you change them 
on the Device/Config tabsheet .

The next chapter explains why this directory 
is empty (except for this README file), 
and where to find the files which may be placed in it.



Where to find these *.DEV files ?
-------------------------------------------------------

Please note that the *.DEV files are Microchip's property,
and the MPLAB(tm) IDE LICENSE GRANT does not allow me to
include these files in the WinPic installation, because..
(quoted from the MPLAB IDE LICENSE GRANT) :

 >
 > You may not reverse engineer [..] Software 
 > and may not copy or reproduce all or any portion of Software.
 >

For this reason, if you need a "decoder" for all bits
in the CONFIGURATION REGISTERS, copy the *.dev file into 
this directory, and add *the name* of that file in WinPic's
device info file. Alternatively, set the full path into
MPLAB's "device"-folder on the Options tab.

The DEV files should be somewhere under "Program Files"
(or "Programme" if you use a german PC) in the directory
  ?...\Microchip\MPLAB IDE\Device .
It contains several megabytes of *.dev files, so only
copy the file you really need.

Some of the devices in WinPic's built-in "info"-table 
already have the appropriate filenames already set :
   - dsPIC30F2010.dev
   - PIC18F2550.dev
(and possibly some others too).




   
