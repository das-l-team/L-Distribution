/*----- Help Topic Identifiers for the PIC Programmer   ---------*/
/*                                                               */
/* Author:         W.Buescher (DL4YHF)                           */
/* Revision Date:  Sep. 25,  2000   .                            */
/*                                                               */
/* Recompile the C++-Project AND the Help File after changes !!  */
/* The Help File can be compiled using Microsoft Help Workshop   */
/*                     and WPicHelp.hpj + HelpSrc\xyz.rtf .      */
/* The Help Compiler will include THIS C-FILE as [MAP]-section.  */
/*---------------------------------------------------------------*/

        // default-value of HelpContext-property
#define HELPID_DEFAULT                0

        // Help topics for context sensitive help (F1)
#define HELPID_MAIN_INDEX             100
#define HELPID_MAIN_WINDOW            110
#define HELPID_COM_INTERFACE          120
#define HELPID_LPT_INTERFACES         130
#define HELPID_CUSTOM_INTERFACES      140
#define HELPID_ID_LOCATIONS           150

#define HELPID_FAQ_LISTS              1000

#ifdef _YHF_HELP_  // if YHF_Help.h has been included.. (for main program ONLY)
  extern T_YHF_HelpMapEntry MyHelpMap[];
#endif


/* EOF <helpids.h> */
