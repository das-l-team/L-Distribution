/*----- Help Topic Identifiers for the PIC PROGRAMMER       -----*/
/*                                                               */
/* Author:         Wolfgang Buescher (DL4YHF)                    */
/* Revision Date:  Dec . 24,  2001   .                           */
/*                                                               */
/* If you are using an old-style HELP-FILE (*.hlp):              */
/*   Recompile the C++-Project AND the Help File after changes ! */
/*   The Help File can be compiled using Microsoft Help Workshop */
/*                     and SpecHelp.hpj + HelpSrc\SpecHelp.rtf . */
/*   The Help Compiler will include THIS C-FILE as [MAP]-section.*/
/*                                                               */
/* If you use an HTML-based help system (preferred, *.htm) :     */
/*   Take care to enter important "marker names" (="anchors")    */
/*   here in a table of T_YHF_HelpMapEntry items.                */
/*                                                               */
/* Latest changes:                                               */
/*  Sept. 19, 2001: Modified the whole thing to get rid of       */
/*              WinHelp.exe and Microsoft's LOUSY HELP COMPILER. */
/*          From now on, an HTML browser is required to view the */
/*          help pages.                                          */
/*---------------------------------------------------------------*/

// #include "VCL.H"   // NO-NO !
// #include "ShellApi.h"
#include "Windows.h"

#pragma hdrstop   // Borland Stuff. No precompiled headers after this please.

#include "YHF_Help.h"  // DL4YHF's HTML-replacement for WinHelp
#include "HelpIDs.h"   // header file with help topic ID's ("Context ID's")


//------------- "Conversion Table"  for help topic IDs -> HTML links --------
T_YHF_HelpMapEntry MyHelpMap[] =
{ // iHelpContext               html_file_name   html_marker_name
 { HELPID_MAIN_INDEX          , "index.htm",     "\0"             },
 { HELPID_COM_INTERFACE       , "index.htm",     "simple_prog"    },
 { HELPID_LPT_INTERFACES      , "index.htm",     "lpt_interfaces" },
 { HELPID_CUSTOM_INTERFACES   , "index.htm",     "custom_interfaces" },
 { HELPID_ID_LOCATIONS        , "index.htm",     "id_locations"   },
 { HELPID_FAQ_LISTS           , "winpic_faq.htm", "\0"            },
 // .-.-.
 { 0 /* end of list*/         , "\0",            "\0"        }
};




/* EOF <helpids.cpp> */
