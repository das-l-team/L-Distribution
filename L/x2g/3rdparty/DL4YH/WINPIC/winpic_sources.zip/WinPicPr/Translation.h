/*========================================================================*/
/*                                                                        */
/*   Translation of all visible strings of the   PIC Programming Tool .   */
/*                                                                        */
/*  Revision history (YYYY-MM-DD) :   see   *.c                           */
/*========================================================================*/


#define TR_OFFS_ENGLISH  0
#define TR_OFFS_GERMAN   1
#define TR_OFFS_FRENCH   2
#define TR_OFFS_ITALIAN  3
#define TR_OFFS_SPANISH  4
#define TR_OFFS_RESERVE  5  // portugese, dutch, danish, russian, or what ? up 2 u !
#define TR_LANGUAGES     6

extern const char *TranslationTable[]; // In "Translation.c" :
            // Translation table from english "master language"
            // into german and -possibly- other languages.


