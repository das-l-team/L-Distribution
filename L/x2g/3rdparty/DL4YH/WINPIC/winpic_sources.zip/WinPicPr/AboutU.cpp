/*-------------------------------------------------------------------------*/
/* AboutU.cpp                                                              */
/*                                                                         */
/*   The inevitable "About" box every windoze program should have.         */
/*                                                                         */
/*-------------------------------------------------------------------------*/


//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "AboutU.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAbtForm *AbtForm;
//---------------------------------------------------------------------------
__fastcall TAbtForm::TAbtForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAbtForm::FormActivate(TObject *Sender)
{
  Lab_Compiled->Caption = __DATE__;        
}
//---------------------------------------------------------------------------

void __fastcall TAbtForm::Btn_OKClick(TObject *Sender)
{
  ModalResult = mrOk;        
}
//---------------------------------------------------------------------------






