//---------------------------------------------------------------------------
#ifndef AboutUH
#define AboutUH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAbtForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Mem_Info;
        TButton *Btn_OK;
        TBevel *Bevel1;
        TLabel *Label1;
        TLabel *Lab_Compiled;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall Btn_OKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TAbtForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAbtForm *AbtForm;
//---------------------------------------------------------------------------
#endif
