//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("WinPic.res");
USEFORM("WinPicPr.cpp", PicMain);
USEUNIT("Config.cpp");
USEUNIT("PIC_PRG.cpp");
USEUNIT("PIC_HEX.cpp");
USEUNIT("PIC_HW.cpp");
USEFORM("AboutU.cpp", AbtForm);
USEUNIT("..\YHF_Tools\YHF_Help.cpp");
USEUNIT("Helpids.cpp");
USEUNIT("..\SMPORT\TSmPort.cpp");
USEUNIT("Devices.cpp");
USEUNIT("..\YHF_Tools\YHF_MultiLang.cpp");
USEUNIT("Translation.c");
USEFORM("ToolWin1.cpp", ToolForm);
USEUNIT("..\YHF_Tools\YHF_Dialogs.cpp");
USEUNIT("..\YHF_Tools\QFile.c");
USEUNIT("dsPIC_PRG.cpp");
USEUNIT("LoadHex.C");
USEUNIT("18f\PIC18F_PRG.cpp");
USEUNIT("PIC10F_PRG.cpp");
USEFILE("APPL.h");
USEUNIT("PIC16F7x_PRG.c");
USEUNIT("..\SMPORT\AllowIoWrapper.c");
USEUNIT("PIC16F716_PRG.c");
USEOBJ("..\SMPORT\objfiles\inoutport.obj");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TPicMain), &PicMain);
                 Application->CreateForm(__classid(TAbtForm), &AbtForm);
                 Application->CreateForm(__classid(TToolForm), &ToolForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
