SmallPort wrapper for C++
----------------------------------------------------------
 By Wolfgang Buescher (DL4YHF@qsl.net)  .
 SmallPort written by  Alexander Weitzman .

Files you may find in this directory:

 TSmPort.cpp = Implementation of a C++ class (by W.Buescher) 
               which can initialize and call the SMALLPORT driver 
 TSmPort.h   = header for the C++ class widh some definitions

 BCB_Test.*  = A tiny test application which I used to test 
               the TSmPort class.  Compiled with Borland C++ Builder V4.
 SmallPort.pas = sourcecode of a DELPHI COMPONENT (by A.Weitzman).
               I used this as a template when writing TSmPort.cpp.
 SMPORT.C    = sourcecode for the Small Port driver (by A.Weitzman)
 hwunit,hwdemo = Demo program by A.Weitzman. Uses the DELPHI COMPONENT.
 README_SMPORT.TXT = Information by A.Weitzman about Small Port .
                 I renamed it from README to README_SMPORT .



What is SmallPort ?
----------------------------------------------------------
 Smallport is a kernel-mode driver for direct hardware access
 under Win95, Win98, Win NT, Win ME, Win2000 (and possibly Win XP).
 Written by A.Weitzman .  From his info file:
  > Copy file "smport.vxd" to "Windows\System" directory 
  > or to directory of your application for Win 9x
  > or "smport.sys" to "WinNT\SYSTEM32" (or to application folder). 

 Search the net for "SMPORT"+"Weitzmann" if you need an update 
 of the driver itself.




What is TSmPort ?
----------------------------------------------------------------
 TSmPort is just a C++ class with all the routines needed to call the
 SMPORT.VXD or SMPORT.SYS driver, depending on what version of windoze
 you are using. Don't forget to copy the VXD//SYS - file into the 
 system directory or the directory where your application shall run from.

 You may find an update for the SMALLPORT WRAPPER (not SmallPort itself)
 somewhere at www.qsl.net/DL4YHF.

 TSmPort tested under 
   - Windows 95                :   ok
   - Windows 98 (first edition):   ok
   - Windows 98 Second Edition :   ok





- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Kudos and all the flowers belong to Alexander Weitzman who did the hard work.
I just wrote the C++ class but not the driver itself.



 Wolfgang Buescher,    Spenge/Germany,  January 2002 