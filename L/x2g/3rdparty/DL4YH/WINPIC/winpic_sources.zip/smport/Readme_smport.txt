SmallPort Delphi Component.

Thank you for trying SmallPort Component.

Now I updated it for work with Windows NT/2000.

This component allows you to reach hardware ports using  "smport.vxd" driver with Win95/98 
and WIN NT/2000 - driver "smport.sys".
It works a little bit faster and stable than regular assembler commands, that they usual use 
to reach h/w ports in Win95/98 (in Windows NT or 2000 this access is impossible). 

To install this component use Component >>Install Component>>Browse>> \\..\SmallPort.pas - for Delphi2,3,4,5 and choose file 
SmallPort.pas (Don't foget to set path in Tools>>Environment Options, page Library).

Copy file "smport.vxd" to "Windows\System" directory or to directory of your application for Win 9x
or "smport.sys" to "WinNT\SYSTEM32" (or to application folder). 
Put component on your form and set property Opened to true. SmPort will open driver and now is ready to 
perform I/O operations. (I removed MessageBox, now possible to test System Error using LastError
property(look below) if error occured and give a message.

Properties:
 Opened - read/write : boolean : open and close "smport.vxd".
 DriverHandle -read only : boolean: handle of driver.
 IOResult : read only: boolean :true if last I/O operation successful. I wanted to remove this 
property, because now you can use LastError, I\m goint to remove it in future versions.
 Port : read/write : array: implementation Pascal array Port[portaddress].

Procedures and functions:
 Create : constructor.
 Destroy : destructor.
 OpenDriver.
 CloseDriver.
 IsOpen.
 ReadByte: function, read byte from given port.
 WriteByte : procedure, writes byte to port with given adress.
 ReadWord: function, read word from given port.
 WriteWord : procedure, writes word to port with given adress.
 ReadDWord: function, read dword from given port.
 WriteDWord : procedure, writes dword to port with given adress.

I use this component with Delphi 4, but I don't see any problem to use it with other 32 bit versions
of Delphi.

Now I tested it with Delphi 2, 3, 4,5!

I got some mail,where they said me, that SmallPort impossible to install
on Delphi 3. I checked it and made small changes: all declarations "xxx: Cardinal;" replaced
with "xxx: DWORD". Now I tested SmallPort on Delphi 3.
I include small demo program in zip file. Don't forget to copy "smallport.vxd" ("smport.sys") to your 
"WINDOWS\SYSTEM" directory!(Or in the same directory where your program is).
 New: I add new function: SpeakerOn and SpeakerOff like old Pascal Sound and Nosound procedures.
Also new procedure Sound(...), that gets as parameters frequency and duration and output 
sound to PC-Speaker.
 New: I add 2 properties: PortW-read and write to port WORD and PortDW -DWORD.

New run-time Property : LastError: if any error occured, this property contains Windows error code,
if no errors - ERROS_SUCCESS (0).

I had a lot of questions about vxd source, so I decided to include it to package.

Contact the author
Please direct all correspondence to  Alexander Weitzman at: mailto: alweit1@hotmail.com
Please be generous with questions, comments and suggestions. 
Thanks and hope to hear from you soon. 

Alexander Weitzman




-----------------------------------------------------------------------------------------------------

Additional note by Wolfgang Buescher (DL4YHF),  2004-09-05 :

When compiling the original TSmPort.cpp with Borland C++Builder V6 will not be possible,
because of a name conflict between Borland's libraries and TSmPort.H .   See sourcecode for details !



