;*******************************************************************************
;*
;*  C-Control/C-Cross-Compiler Assembler Headers
;*  68hc05b6.h
;*
;*  Copyright (C) 2005, 2006  Oliver Haag
;*
;*  This file is part of the C-Control/C-Cross-Compiler.
;*
;*  The C-Control/C-Cross-Compiler is free software; you can redistribute it
;*  and/or modify it under the terms of the GNU General Public License as
;*  published by the Free Software Foundation; either version 2 of the License,
;*  or (at your option) any later version.
;*
;*  The C-Control/C-Cross-Compiler is distributed in the hope that it will be
;*  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
;*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
;*  Public License or the file COPYING for more details.
;*
;*  You should have received a copy of the GNU General Public License along with
;*  this program; if not, write to the Free Software Foundation, Inc.,
;*  51 Franklin St, Fifth Floor, Boston, MA 02110, USA 
;*
;*******************************************************************************


; Ports
PORTA                   equ         $00 ; Port A data register
PORTB                   equ         $01 ; Port B data register
PORTC                   equ         $02 ; Port C data register
PORTD                   equ         $03 ; Port D input data register
DDRA                    equ         $04 ; Port A data direction register
DDRB                    equ         $05 ; Port B data direction register
DDRC                    equ         $06 ; Port C data direction register

; EEPROM
EECR                    equ         $07 ; EEPROM/ECLK control register
ECLK                    equ          #3 ; External clock output bit
E1ERA                   equ          #2 ; EEPROM erase/programming bit
E1LAT                   equ          #1 ; EEPROM programming latch enable bit
E1PGM                   equ          #0 ; EEPROM charge pump enable/disable

; Analogports
ADDATA                  equ         $08 ; A/D data register
ADSTAT                  equ         $09 ; A/D status/control register
COCO                    equ          #7 ; Conversion complete flag
ADRC                    equ          #6 ; A/D RC oscillator control
ADON                    equ          #5 ; A/D converter on
CH3                     equ          #3 ; A/D channel 3
CH2                     equ          #2 ; A/D channel 2
CH1                     equ          #1 ; A/D channel 1
CH0                     equ          #0 ; A/D channel 0

; PWM
PLMA                    equ         $0a ; Pulse length modulation A
PLMB                    equ         $0b ; Pulse length modulation B
MISC                    equ         $0c ; Miscellaneous register
POR                     equ          #7 ; Power-on reset bit
INTP                    equ          #6 ; External interrupt senstivity options - Positive edge
INTN                    equ          #5 ; External interrupt senstivity options - Negative edge
INTE                    equ          #4 ; External interrupt enable
SFA                     equ          #3 ; Slow or fast mode selection for PLMA
SFB                     equ          #2 ; Slow or fast mode selection for PLMB
SM                      equ          #1 ; Slow mode
WDOG                    equ          #0 ; Watchdog enable/disable

; SCI
BAUD                    equ         $0d ; SCI baud rate register
SCP1                    equ          #7 ; Serial prescaler select bits
SCP0                    equ          #6 ; "
SCT2                    equ          #5 ; SCI rate select bits (transmitter)
SCT1                    equ          #4 ; "
SCT0                    equ          #3 ; "
SCR2                    equ          #2 ; SCI rate select bits (reciever)
SCR1                    equ          #1 ; "
SCR0                    equ          #0 ; "
SCCR1                   equ         $0e ; SCI control register 1
R8                      equ          #7 ; Recieve data bit 8
T8                      equ          #6 ; Transmit data bit 8
M                       equ          #4 ; Mode (select character format)
WAKE                    equ          #3 ; Wake-up mode select
CPOL                    equ          #2 ; Clock polarity
CPHA                    equ          #1 ; Clock phase
LBCL                    equ          #0 ; Last bit clock
SCCR2                   equ         $0f ; SCI control register 2
TIE                     equ          #7 ; Transmit interrupt enable
TCIE                    equ          #6 ; Transmit complete interrupt enable
RIE                     equ          #5 ; Reciever interrupt enable
ILIE                    equ          #4 ; Idle line interrupt enable
TE                      equ          #3 ; Transmitter enable
RE                      equ          #2 ; Reciever enable
RWU                     equ          #1 ; Reciever wake-up
SBK                     equ          #0 ; Send break
SCSR                    equ         $10 ; SCI status register
TDRE                    equ          #7 ; Transmit data register empty flag
TC                      equ          #6 ; Transmit complete flag
RDRF                    equ          #5 ; Recieve data register full flag
IDLE                    equ          #4 ; Idle line detected flag
OR                      equ          #3 ; Overrun error flag
NF                      equ          #2 ; Noise error flag
FE                      equ          #1 ; Framing error flag
SCDAT                   equ         $11 ; SCI data register

; Timer
TCR                     equ         $12 ; Timer control register
ICIE                    equ          #7 ; Input captures interrupt enable
OCIE                    equ          #6 ; Output compares interrupt enable
TOIE                    equ          #5 ; Timer overflow interrupt enable
FOLV2                   equ          #4 ; Force output compare 2
FOLV1                   equ          #3 ; Force output compare 1
OLV2                    equ          #2 ; Output level 2
IEDG1                   equ          #1 ; Input edge 1
OLV1                    equ          #0 ; Output level 1
TSR                     equ         $13 ; Timer status register
ICF1                    equ          #7 ; Input capture flag 1
OCF1                    equ          #6 ; Output compare flag 1
TOF                     equ          #5 ; Timer overflow status flag
ICF2                    equ          #4 ; Input capture flag 2
OCF2                    equ          #3 ; Output compare flag 2
ICR1H                   equ         $14 ; Capture high register 1
ICR1L                   equ         $15 ; Capture low register 1
OCR1H                   equ         $16 ; Compare high register 1
OCR1L                   equ         $17 ; Compare low register 1
TCH                     equ         $18 ; Counter high register
TCL                     equ         $19 ; Counter low register
ATCH                    equ         $1a ; Alternate counter high register
ATCL                    equ         $1b ; Alternate counter low register
ICR2H                   equ         $1c ; Capture high register 2
ICR2L                   equ         $1d ; Capture low register 2
OCR2H                   equ         $1e ; Compare high register 2
OCR2L                   equ         $1f ; Compare low register 2

; Options register
OPTR                    equ       $0100 ; Options register
EE1P                    equ          #1 ; EEPROM protect bit
SEC                     equ          #0 ; Security bit

 end
