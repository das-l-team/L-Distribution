;*******************************************************************************
;*
;*  C-Control/C-Cross-Compiler Assembler Headers
;*  ccontrol.h
;*
;*  Copyright (C) 2005, 2006  Oliver Haag
;*
;*  This file is part of the C-Control/C-Cross-Compiler.
;*
;*  The C-Control/C-Cross-Compiler is free software; you can redistribute it
;*  and/or modify it under the terms of the GNU General Public License as
;*  published by the Free Software Foundation; either version 2 of the License,
;*  or (at your option) any later version.
;*
;*  The C-Control/C-Cross-Compiler is distributed in the hope that it will be
;*  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
;*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
;*  Public License or the file COPYING for more details.
;*
;*  You should have received a copy of the GNU General Public License along with
;*  this program; if not, write to the Free Software Foundation, Inc.,
;*  51 Franklin St, Fifth Floor, Boston, MA 02110, USA 
;*
;*******************************************************************************


; Variablen

; Interrupt-Pointer
IRQPTR                  equ         $50 ; Userpointer f�r IRQ-Interrupt
CAPPTR                  equ         $51 ; Userpointer f�r TIMERCAP-Interrupt
CMPPTR                  equ         $52 ; Userpointer f�r TIMERCMP-Interrupt
OFLPTR                  equ         $53 ; Userpointer f�r TIMEROFL-Interrupt

; C-Control Statusregister
CCSTAT                  equ         $7b ; Allgemeines C-Control Statusregister
DCF77OK                 equ          #0
TIMESET                 equ          #4
SLOWMODE                equ          #5
TOKENIRQ                equ          #6
HANDSHAKE               equ          #7



; C-Control Stack
TOSHBYTE                equ         $91 ; Rechenstack, erstes Word
TOSLBYTE                equ         $92
ST2HBYTE                equ         $93 ; Rechenstack, zweites Word
ST2LBYTE                equ         $94
ST3HBYTE                equ         $95
ST3LBYTE                equ         $96
ST4HBYTE                equ         $97
ST4LBYTE                equ         $98
ST5HBYTE                equ         $99
ST5LBYTE                equ         $9a
ST6HBYTE                equ         $9b
ST6LBYTE                equ         $9c
ST7HBYTE                equ         $9d
ST7LBYTE                equ         $9e

; 24 Bytes CC-RAM ($A1 - $B8)
USERRAM                 equ         $a1 ; Startadresse des Benutzer-RAM Bereichs

; Betriebsystemroutinen

; Stackoperationen
PUSHSTACKB              equ       $1246 ; Bin�rwert (Indexregister) auf den Rechenstack schieben
PUSHSTACKC              equ       $125c ; Bytewert (Indexregister) auf den Rechenstack schieben
PUSHSTACKW              equ       $1267 ; Wordwert ($d2 und $d3) auf den Rechenstack schieben
PSWHBYTE                equ         $d2 ; Highbyte des Wordwertes
PSWLBYTE                equ         $d3 ; Lowbyte des Wordwertes
POPSTACK                equ       $11b8 ; TOS-Word unbeeinflusst, Rest wird 1 Word zum TOS-Word hin verschoben
					; (Wenn 2 Words als Parameter verwendet werden und 1 Word zur�ckgegeben wird)

 end
