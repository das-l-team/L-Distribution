#define Q12MHZ


#include <asm/q12.h>                    // q12.s19 hochladen nicht vergessen
#include <sys/ccontrol.h>


void main()
{
	char[0] counter;
	
	rs_sendstr("Ohne Anpassung (Punkt = delay(50)): ");
	for(counter = 0; counter <= 10; counter ++)
	{
		delay(50);
		rs_sendstr(".");
	}
	setregister(CMPPTR, TIMERCMP);  // Neuer Timercompare-Pointer
	
	rs_sendstr("\nMit Anpassung (Punkt = delay(50)): ");
	for(counter = 0; counter <= 10; counter ++)
	{
		delay(50);
		rs_sendstr(".");
	}
}