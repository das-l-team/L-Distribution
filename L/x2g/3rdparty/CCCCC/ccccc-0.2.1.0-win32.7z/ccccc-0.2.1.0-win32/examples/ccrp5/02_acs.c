#include <ccrp5.h>


void main()
{
	char[0] subsysstate;
	bool[0] acsl, acsr;
	
	initrp5();
	leds(LEDX, 0);
	delay(5);
	acs_power(ACSLO);
	
	while(true)
	{
		delay(5);
		subsysstate = subsys_getstate();
		leds(LED1, acsr);
		leds(LED4, acsl);
	}
}
