#include <ccrp5be.h>


void runbleds();                        // Das Lauflicht, das wir aus 01_leds.c kennen 1x hin und her


void main()
{
	char[0] eledstate;
	
	initrp5();
	
	while(true)
	{
		for(eledstate = ELED1; eledstate <= ELED7; eledstate <<= 1)
		{
			eleds(ELEDX, eledstate); // Geht, aber eleds ist hier nicht n�tig da alle LED's angesteuert werden
			runbleds();
		}
		for(eledstate = ELED8; eledstate >= ELED2; eledstate >>= 1)
		{
			setledport(eledstate); // Braucht f�r die Ausf�hrung k�rzer und reicht in diesem Fall
			runbleds();
		}
	}
}

void runbleds()
{
	char[1] ledstate;
	
	for(ledstate = LED1; ledstate <= LED3; ledstate <<= 1)
	{
		leds(LEDX, ledstate);
		delay(2);
	}
	for(ledstate = LED4; ledstate >= LED2; ledstate >>= 1)
	{
		leds(LEDX, ledstate);
		delay(2);
	}
}
