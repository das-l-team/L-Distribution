#include <ccrp5.h>


void main()
{
	char[0] ledstate;
	
	initrp5();
	
	while(true)
	{
		for(ledstate = LED1; ledstate <= LED3; ledstate <<= 1)
		{
			leds(LEDX, ledstate);
			delay(5);
		}
		for(ledstate = LED4; ledstate >= LED2; ledstate >>= 1)
		{
			leds(LEDX, ledstate);
			delay(5);
		}
	}
}
