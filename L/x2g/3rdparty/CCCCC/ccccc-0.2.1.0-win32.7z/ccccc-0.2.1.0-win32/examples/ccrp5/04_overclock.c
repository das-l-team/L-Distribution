#define Q12MHZ


#include <ccrp5.h>
#include <sys/ccontrol.h>


void main()
{
	char[0] ledstate;
	
	initrp5();                      // �bernimmt die Umstellung auf 12 MHz wenn Q12MHZ definiert ist
	
	while(true)
	{
		for(ledstate = LED1; ledstate <= LED3; ledstate <<= 1)
		{
			leds(LEDX, ledstate);
			delay(5);
		}
		for(ledstate = LED4; ledstate >= LED2; ledstate >>= 1)
		{
			leds(LEDX, ledstate);
			delay(5);
		}
	}
}
