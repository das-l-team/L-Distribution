#include <sys/baud.h>


void main()
{
	int[0] charid;
	
	rs_baud(B9600);
	
	for(charid = 0; charid < 256; charid++)
	{
		rs_sendint(charid);     // Zahl als ASCII formatiert senden
		rs_sendstr(":\t");      // Ein Doppenpunkt mit und ein Tabulator
		rs_send(charid);        // Zeichen mit dem jeweiligen ASCII-Code senden
		rs_sendstr("\n");       // Und in die n�chste Zeile gehen
	}
}
