
DASMx - A microprocessor opcode disassembler

(c) Copyright 1996-1999   Conquest Consultants

Version 1.30, 6th October 1999


This distribution contains the following files:

readme.txt               This file
dasmx.exe                Executable (a Win32 console application)
dasmx.htm                Documentation in HTML format
dasmx.pdf                Documentation in Adobe Acrobat format
dasmx.txt                Documentation in plain text
examples\*.sym           Example symbol files

NOTE: Netscape 4.x seems to get confused by the font settings in
the HTML version of the documentation.  Either use Internet
Explorer 4 or, better, view/print the Acrobat version.

*** Please read the distribution, copyright and disclaimer notices
in the documentation. ***
